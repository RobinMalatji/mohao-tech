# How to finish the Return-to-work CV kit

A CV for someone returning after a break, with the break stated once and the recent proof stated clearly.

## Replace the sample

1. Put your name and city in the heading. A full street address is unnecessary.
2. Replace each role with yours. Keep the shape: action and result.
3. Delete a skill you cannot discuss for five minutes.
4. You do not owe a medical story.
5. A recent small piece of work is enough to show currency.

## Before you send

- The file name is YourName-Role.pdf.
- A person who does not know you can see the target role in the first three lines.
- You can defend every number in an interview.

> The employment history in this file is fictional sample text. Replace every line before you send it. This kit does not guarantee interviews.
