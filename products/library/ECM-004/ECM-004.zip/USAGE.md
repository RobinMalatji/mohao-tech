# How to use Abandoned cart email copy

*DOCX and PDF shop kit*

Two emails for a buyer who left before paying. They do not invent a discount.

## Who it is for

Shops that can send a cart reminder.

## Compatibility

- Word or Docs for DOCX
- Excel for workbooks
- A text editor for Markdown and CSV

## Before you start

1. Read the README and this usage guide.
2. Open the main deliverable and replace every sample figure or sample sentence with your own.
3. Keep a copy of the original download before you edit it.
4. Check the licence before you share the edited file with anyone else.

## What you should see

- A finished sample you edit
- The boundary of what the file does not decide
- A checklist before you publish
