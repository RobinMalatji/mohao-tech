# How to use Pipeline weighted value

*Excel summary, CSV dataset, and DAX measures*

Open opportunity value by stage. Weighting is not applied because the stage odds were not measured. Load the CSV into Excel or Power BI Desktop. The DAX file is text you paste into a measure. This package does not include a PBIX file.

## Who it is for

A salesperson who wants the unweighted value first.

## Compatibility

- Excel for the workbook and CSV
- Power BI Desktop if you paste the DAX yourself
- No PBIX file is included

## Before you start

1. Read the README and this usage guide.
2. Open the main deliverable and replace every sample figure or sample sentence with your own.
3. Keep a copy of the original download before you edit it.
4. Check the licence before you share the edited file with anyone else.

## What you should see

- A CSV with a real grain and sample rows
- DAX that names the columns in that CSV
- An Excel total you can check against the rows
