# Supplier comparison licence

*Version 1.0.0 · commercial-single*

This is a practical usage licence from MOHAO for the files in this package. It is not a substitute for legal advice.

## What you may do

- One business may use and edit these files internally, including while delivering that business's own service to its clients.
- You may not resell the source files or republish them as a template library, course, or downloadable product.
- Sample figures, names, and businesses in the files are fictional. Replace them before you share a filled-in copy outside your team.

## What stays with MOHAO

MOHAO keeps ownership of the original files. Buying a licence does not transfer copyright. Trademarks, including MOHAO, stay with their owners.

## Support and liability

The files are provided as a working product you can edit. MOHAO is not liable for decisions you make from sample numbers, formulas, prompts, or draft wording. Check figures, formulas, and wording before you rely on them.

> This is a working draft for a South African online shop. It is not legal advice. Have a lawyer read it before you publish it as your policy.
