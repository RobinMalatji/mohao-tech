# Studio coordinator CV kit licence

*Version 1.0.0 · personal*

This is a practical usage licence from MOHAO for the files in this package. It is not a substitute for legal advice.

## What you may do

- One named person may use and edit these files for personal planning, study, or their own job.
- You may not resell the files, post them for public download, or include them in a product, course, or template pack that you sell.
- Sample figures, names, and businesses in the files are fictional. Replace them with your own information.

## What stays with MOHAO

MOHAO keeps ownership of the original files. Buying a licence does not transfer copyright. Trademarks, including MOHAO, stay with their owners.

## Support and liability

The files are provided as a working product you can edit. MOHAO is not liable for decisions you make from sample numbers, formulas, prompts, or draft wording. Check figures, formulas, and wording before you rely on them.

> The employment history in this file is fictional sample text. Replace every line before you send it. This kit does not guarantee interviews.
